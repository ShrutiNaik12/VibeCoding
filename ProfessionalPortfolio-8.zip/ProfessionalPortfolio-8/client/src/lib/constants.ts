export const RESUME_URL = "https://www.linkedin.com/in/shruti-sharad-naik/";

export const CONTACT_INFO = {
  email: "shrutisharad.naik@mavs.uta.edu",
  linkedin: "www.linkedin.com/in/shruti-sharad-naik/",
  github: "github.com/ShrutiNaik12",
  location: "Austin, Texas, United States",
};

export const TECHNOLOGIES = [
  "Python (ML Libraries)",
  "Large Language Models",
  "PySpark",
  "RAG Systems",
  "SQL",
  "TensorFlow/Keras",
];

export const EXPERIENCES = [
  {
    title: "Data Scientist II",
    company: "Humata Health",
    period: "November 2023 - Present",
    responsibilities: [
      "Built and deployed NLP models to automate prior authorization decisions for major health facility organizations resulting in 92% accuracy and reduction in decision process time.",
      "Implemented RAG based conversational AI agent to identify clinically relevant documents to Medical Criteria Guidelines, CPT, and ICD-10 codes.",
      "Developed a custom model training pipeline in Databricks, with data processing in Pyspark and experiment tracking in MLFlow.",
      "Created internal monitoring tool to identify prediction errors of deployed models and generate backlog alerts.",
    ],
  },
  {
    title: "Data Scientist I",
    company: "Olive",
    period: "August 2021 - November 2023",
    responsibilities: [
      "Implemented Document Classification NLP model using semantic similarity on text content and entity-based policy rules with 92% accuracy.",
      "Created an alerts channel on slack to notify if any backlogs of services, to get immediate information of errors or other issues.",
      "Documented and presented model pipeline and other processes to technical and non-technical teams.",
    ],
  },
  {
    title: "Research Associate",
    company: "The Ohio State University Wexner Medical Center",
    period: "August 2020 - July 2021",
    responsibilities: [
      "Processed and analyzed 3D DICOM MRI images to study the stiffness of tissues in tumor patients for non-invasive diagnostic insight.",
      "Designed a user-friendly GUI algorithm using MATLAB for image segmentation to accelerate and ease the data study.",
    ],
  },
];

export const EDUCATION = [
  {
    degree: "Master's Degree",
    field: "Bioengineering and Biomedical Engineering",
    institution: "The University of Texas at Arlington",
    period: "2018 - 2020",
    description:
      "Specialized in applying advanced data science and machine learning techniques to biomedical research and healthcare challenges.",
  },
  {
    degree: "Bachelor of Engineering",
    field: "Biomedical Engineering",
    institution: "Mumbai University",
    period: "Graduation Year Not Specified",
    description:
      "Built a strong foundation in biomedical engineering principles and medical device technologies.",
  },
];

export const SKILL_CATEGORIES = [
  {
    title: "AI & Machine Learning",
    skills: [
      { name: "Large Language Models (LLMs)", proficiency: 95 },
      { name: "Retrieval-Augmented Generation", proficiency: 90 },
      { name: "Neural Networks", proficiency: 85 },
      { name: "Natural Language Processing", proficiency: 90 },
    ],
  },
  {
    title: "Programming",
    skills: [
      { name: "Python (ML Libraries)", proficiency: 95 },
      { name: "SQL", proficiency: 85 },
      { name: "MATLAB", proficiency: 80 },
      { name: "R", proficiency: 75 },
    ],
  },
  {
    title: "Data Science Tools",
    skills: [
      { name: "PySpark", proficiency: 90 },
      { name: "TensorFlow/Keras", proficiency: 85 },
      { name: "Scikit-learn", proficiency: 90 },
      { name: "Pandas/NumPy", proficiency: 95 },
    ],
  },
  {
    title: "Data Engineering",
    skills: [
      { name: "ETL/ELT Pipelines", proficiency: 85 },
      { name: "Data Ingestion", proficiency: 90 },
      { name: "CI/CD", proficiency: 80 },
      { name: "Databricks", proficiency: 85 },
    ],
  },
  {
    title: "Healthcare Domain",
    skills: [
      { name: "Prior Authorization", proficiency: 90 },
      { name: "Medical Imaging", proficiency: 85 },
      { name: "Clinical Documentation", proficiency: 90 },
      { name: "Medical Devices", proficiency: 75 },
    ],
  },
  {
    title: "Languages",
    skills: [
      { name: "English", proficiency: 100 },
      { name: "Hindi", proficiency: 90 },
      { name: "Marathi", proficiency: 95 },
      { name: "Konkani", proficiency: 90 },
    ],
  },
];
