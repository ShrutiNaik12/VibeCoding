import { motion } from "framer-motion";
import { GraduationCap } from "lucide-react";

export default function Education() {
  const educationData = [
    {
      degree: "Master's Degree",
      field: "Bioengineering and Biomedical Engineering",
      institution: "The University of Texas at Arlington",
      period: "2018 - 2020",
      description:
        "Specialized in applying advanced data science and machine learning techniques to biomedical research and healthcare challenges.",
    },
    {
      degree: "Bachelor of Engineering",
      field: "Biomedical Engineering",
      institution: "Mumbai University",
      period: "Graduation Year Not Specified",
      description:
        "Built a strong foundation in biomedical engineering principles and medical device technologies.",
    },
  ];

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.2,
      },
    },
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: { opacity: 1, y: 0, transition: { duration: 0.5 } },
  };

  return (
    <section id="education" className="py-20 px-6">
      <div className="container mx-auto">
        <motion.h2
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
          className="text-3xl font-bold text-primary mb-12 flex items-center"
        >
          <span className="text-accent mr-3">04.</span> Education
          <span className="ml-4 h-px bg-gray-300 flex-grow"></span>
        </motion.h2>

        <motion.div
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
          className="grid grid-cols-1 md:grid-cols-2 gap-8"
        >
          {educationData.map((education, index) => (
            <motion.div
              key={index}
              variants={itemVariants}
              className="bg-white rounded-lg shadow-md p-6 border-t-4 border-accent hover:shadow-lg transition-shadow duration-300"
            >
              <div className="flex items-center mb-4">
                <div className="text-accent text-2xl mr-4">
                  <GraduationCap size={28} />
                </div>
                <div>
                  <h3 className="text-xl font-bold text-primary">
                    {education.degree}
                  </h3>
                  <p className="text-black">{education.field}</p>
                </div>
              </div>
              <div className="mb-4">
                <p className="font-medium">{education.institution}</p>
                <p className="text-black">{education.period}</p>
              </div>
              <p className="text-black">{education.description}</p>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  );
}
