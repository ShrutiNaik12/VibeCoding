import { useState, useEffect } from "react";
import Header from "./Header";
import Hero from "./Hero";
import About from "./About";
import Experience from "./Experience";
import Skills from "./Skills";
import Education from "./Education";
import Contact from "./Contact";
import Footer from "./Footer";
import { useScrollPosition } from "@/hooks/useScrollPosition";

export default function Layout() {
  const scrollPosition = useScrollPosition();
  const [activeSection, setActiveSection] = useState("hero");

  useEffect(() => {
    const sections = ["hero", "about", "experience", "skills", "education", "contact"];
    
    for (const section of sections) {
      const element = document.getElementById(section);
      if (!element) continue;
      
      const rect = element.getBoundingClientRect();
      const offset = 100; // Adjust based on header height
      
      if (rect.top <= offset && rect.bottom >= offset) {
        setActiveSection(section);
        break;
      }
    }
  }, [scrollPosition]);

  return (
    <div className="flex flex-col min-h-screen">
      <Header activeSection={activeSection} />
      <main className="flex-grow">
        <Hero />
        <About />
        <Experience />
        <Skills />
        <Education />
        <Contact />
      </main>
      <Footer />
    </div>
  );
}
