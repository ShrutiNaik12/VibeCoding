import { motion } from "framer-motion";
import { Mail, Linkedin, Github } from "lucide-react";

export default function Footer() {
  const socialLinks = [
    {
      icon: Mail,
      href: "mailto:shrutisharad.naik@mavs.uta.edu",
      label: "Email",
    },
    {
      icon: Linkedin,
      href: "https://www.linkedin.com/in/shruti-sharad-naik/",
      label: "LinkedIn",
    },
    {
      icon: Github,
      href: "https://github.com/ShrutiNaik12",
      label: "GitHub",
    },
  ];

  const currentYear = new Date().getFullYear();

  return (
    <footer className="py-8 px-6 bg-secondary text-white">
      <div className="container mx-auto">
        <div className="flex flex-col md:flex-row justify-between items-center">
          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.5 }}
          >
            &copy; {currentYear} Shruti Naik. All rights reserved.
          </motion.p>

          <div className="flex space-x-6 mt-4 md:mt-0">
            {socialLinks.map((link, index) => (
              <motion.a
                key={index}
                href={link.href}
                target={link.href.startsWith("mailto:") ? "_self" : "_blank"}
                rel="noopener noreferrer"
                aria-label={link.label}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.3, delay: index * 0.1 }}
                className="text-white hover:text-accent transform transition duration-300 hover:-translate-y-1"
              >
                <link.icon size={20} />
              </motion.a>
            ))}
          </div>
        </div>

        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.5, delay: 0.5 }}
          className="text-center mt-6 text-sm text-gray-400"
        >
          <p>Designed and built with ❤️</p>
        </motion.div>
      </div>
    </footer>
  );
}
