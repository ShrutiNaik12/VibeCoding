import { motion } from "framer-motion";

export default function About() {
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.2,
      },
    },
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: { opacity: 1, y: 0 },
  };

  const technologies = [
    "Python (ML Libraries)",
    "Large Language Models",
    "PySpark",
    "RAG Systems",
    "SQL",
    "TensorFlow/Keras",
  ];

  return (
    <section id="about" className="py-20 px-6 bg-gray-50">
      <div className="container mx-auto">
        <motion.h2
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
          className="text-3xl font-bold text-primary mb-8 flex items-center"
        >
          <span className="text-accent mr-3">01.</span> About Me
          <span className="ml-4 h-px bg-gray-300 flex-grow"></span>
        </motion.h2>

        <div className="flex flex-col lg:flex-row items-start gap-12">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: 0.2 }}
            className="lg:w-2/3"
          >
            <p className="text-black mb-6">
              I'm an accomplished Data Scientist pioneering the intersection of Healthcare AI and Natural Language Processing. 
              My expertise drives transformative healthcare solutions that directly impact patient procedures and clinical efficiency.
            </p>
            <p className="text-black mb-6">
              At Humata Health, I've developed high-performing NLP models that achieve 92% accuracy in automating prior authorization decisions, 
              dramatically accelerating the decision process. My innovative RAG-based conversational AI agents identify clinically relevant documentation 
              aligned with Medical Criteria Guidelines, CPT, and ICD-10 codes with unprecedented precision.
            </p>
            <p className="text-black">
              I possess mastery in processing complex real-world healthcare data through advanced Python frameworks (Scikit-learn, PySpark, 
              NumPy, pandas, Keras, TensorFlow) and sophisticated SQL implementations. My passion lies in conquering healthcare's most challenging 
              problems through cutting-edge AI innovation that delivers measurable improvements in patient care.
            </p>

            <motion.div
              variants={containerVariants}
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true }}
              className="mt-8"
            >
              <h3 className="text-xl font-semibold text-primary mb-4">
                Some technologies I work with:
              </h3>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
                {technologies.map((tech, index) => (
                  <motion.div
                    key={index}
                    variants={itemVariants}
                    className="flex items-center"
                  >
                    <div className="text-accent mr-2">▹</div>
                    <span>{tech}</span>
                  </motion.div>
                ))}
              </div>
            </motion.div>
          </motion.div>

          
        </div>
      </div>
    </section>
  );
}
