import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";

export default function Experience() {
  const experiences = [
    {
      title: "Data Scientist II",
      company: "Humata Health",
      period: "November 2023 - Present",
      responsibilities: [
        "Built and deployed NLP models to automate prior authorization decisions for major health facility organizations resulting in 92% accuracy and reduction in decision process time.",
        "Implemented RAG based conversational AI agent to identify clinically relevant documents to Medical Criteria Guidelines, CPT, and ICD-10 codes.",
        "Developed a custom model training pipeline in Databricks, with data processing in Pyspark and experiment tracking in MLFlow.",
        "Created internal monitoring tool to identify prediction errors of deployed models and generate backlog alerts.",
      ],
    },
    {
      title: "Data Scientist I",
      company: "Olive",
      period: "August 2021 - November 2023",
      responsibilities: [
        "Implemented Document Classification NLP model using semantic similarity on text content and entity-based policy rules with 92% accuracy.",
        "Created an alerts channel on slack to notify if any backlogs of services, to get immediate information of errors or other issues.",
        "Documented and presented model pipeline and other processes to technical and non-technical teams.",
      ],
    },
    {
      title: "Research Associate",
      company: "The Ohio State University Wexner Medical Center",
      period: "August 2020 - July 2021",
      responsibilities: [
        "Processed and analyzed 3D DICOM MRI images to study the stiffness of tissues in tumor patients for non-invasive diagnostic insight.",
        "Designed a user-friendly GUI algorithm using MATLAB for image segmentation to accelerate and ease the data study.",
      ],
    },
  ];

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.2,
      },
    },
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: { opacity: 1, y: 0 },
  };

  return (
    <section id="experience" className="py-20 px-6">
      <div className="container mx-auto">
        <motion.h2
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
          className="text-3xl font-bold text-primary mb-12 flex items-center"
        >
          <span className="text-accent mr-3">02.</span> Where I've Worked
          <span className="ml-4 h-px bg-gray-300 flex-grow"></span>
        </motion.h2>

        <motion.div
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
        >
          {experiences.map((exp, index) => (
            <motion.div
              key={index}
              variants={itemVariants}
              className="group bg-white rounded-lg shadow-md p-6 mb-8 border-l-4 border-accent hover:shadow-lg transition-all duration-300 hover:-translate-y-1"
            >
              <div className="flex flex-col md:flex-row justify-between mb-4">
                <h3 className="text-xl font-bold text-primary">{exp.title}</h3>
                <span className="text-accent font-medium">{exp.period}</span>
              </div>
              <h4 className="text-lg font-semibold text-black mb-4">
                {exp.company}
              </h4>
              <ul className="space-y-3">
                {exp.responsibilities.map((responsibility, idx) => (
                  <li key={idx} className="flex">
                    <div className="text-accent mr-2 mt-1">▹</div>
                    <span className="text-black">{responsibility}</span>
                  </li>
                ))}
              </ul>
            </motion.div>
          ))}
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5, delay: 0.6 }}
          className="text-center mt-10"
        >
          <Button
            variant="outline"
            className="border-2 border-accent text-accent hover:bg-accent hover:text-white"
            size="lg"
            onClick={() => window.open("https://www.linkedin.com/in/shruti-sharad-naik/", "_blank")}
          >
            View Full Resume
          </Button>
        </motion.div>
      </div>
    </section>
  );
}
