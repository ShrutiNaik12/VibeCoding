import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import profileImage from "../assets/profile-new.jpg";

export default function Hero() {
  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      window.scrollTo({
        top: element.offsetTop - 80,
        behavior: "smooth",
      });
    }
  };

  return (
    <section id="hero" className="min-h-screen flex items-center pt-16 px-6">
      <div className="container mx-auto">
        <div className="flex flex-col lg:flex-row items-center justify-between">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="lg:w-1/2 mb-10 lg:mb-0"
          >
            <motion.p
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.5, delay: 0.2 }}
              className="text-accent font-medium mb-4"
            >
              Hello, my name is
            </motion.p>
            <motion.h1
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.5, delay: 0.3 }}
              className="text-4xl md:text-5xl lg:text-6xl font-bold text-primary mb-4"
            >
              Shruti Naik
            </motion.h1>
            <motion.h2
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.5, delay: 0.4 }}
              className="text-3xl md:text-4xl lg:text-5xl font-bold text-black mb-6"
            >
              I build AI solutions for healthcare
            </motion.h2>
            <motion.p
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.5, delay: 0.5 }}
              className="text-lg text-black max-w-lg mb-8"
            >
              I'm a Data Scientist specializing in healthcare AI with expertise in NLP, LLMs, and 
              automating prior authorization workflows. Currently elevating patient care through 
              advanced AI technologies at Humata Health.
            </motion.p>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.5, delay: 0.6 }}
              className="flex flex-col sm:flex-row gap-4"
            >
              <Button
                onClick={() => scrollToSection("contact")}
                className="bg-accent hover:bg-accent/90 text-white"
                size="lg"
              >
                Contact Me
              </Button>
              <Button
                onClick={() => scrollToSection("experience")}
                variant="outline"
                className="border-2 border-accent text-accent hover:bg-accent hover:text-white"
                size="lg"
              >
                View My Work
              </Button>
            </motion.div>
          </motion.div>
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.5, delay: 0.3 }}
            className="lg:w-2/5"
          >
            <div className="relative">
              <div className="absolute inset-0 bg-accent rounded-lg transform translate-x-4 translate-y-4"></div>
              <img
                src={profileImage}
                alt="Professional headshot of Shruti Naik"
                className="relative z-10 rounded-lg shadow-xl w-full object-cover h-[400px]"
              />
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
