import { motion } from "framer-motion";
import { 
  Brain, 
  Code, 
  LineChart, 
  Database, 
  HeartPulse
} from "lucide-react";

export default function Skills() {
  const skillCategories = [
    {
      title: "AI & Machine Learning",
      icon: Brain,
      skills: [
        { name: "Large Language Models (LLMs)", proficiency: 95 },
        { name: "Retrieval-Augmented Generation", proficiency: 90 },
        { name: "Neural Networks", proficiency: 85 },
        { name: "Natural Language Processing", proficiency: 90 },
      ],
    },
    {
      title: "Programming",
      icon: Code,
      skills: [
        { name: "Python (ML Libraries)", proficiency: 95 },
        { name: "SQL", proficiency: 85 },
        { name: "MATLAB", proficiency: 80 },
        { name: "R", proficiency: 75 },
      ],
    },
    {
      title: "Data Science Tools",
      icon: LineChart,
      skills: [
        { name: "PySpark", proficiency: 90 },
        { name: "TensorFlow/Keras", proficiency: 85 },
        { name: "Scikit-learn", proficiency: 90 },
        { name: "Pandas/NumPy", proficiency: 95 },
      ],
    },
    {
      title: "Data Engineering",
      icon: Database,
      skills: [
        { name: "ETL/ELT Pipelines", proficiency: 85 },
        { name: "Data Ingestion", proficiency: 90 },
        { name: "CI/CD", proficiency: 80 },
        { name: "Databricks", proficiency: 85 },
      ],
    },
    {
      title: "Healthcare Domain",
      icon: HeartPulse,
      skills: [
        { name: "Prior Authorization", proficiency: 90 },
        { name: "Medical Imaging", proficiency: 85 },
        { name: "Clinical Documentation", proficiency: 90 },
        { name: "Medical Devices", proficiency: 75 },
      ],
    },
    ];

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
      },
    },
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: { opacity: 1, y: 0, transition: { duration: 0.5 } },
  };

  return (
    <section id="skills" className="py-20 px-6 bg-gray-50">
      <div className="container mx-auto">
        <motion.h2
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
          className="text-3xl font-bold text-primary mb-12 flex items-center"
        >
          <span className="text-accent mr-3">03.</span> Skills & Expertise
          <span className="ml-4 h-px bg-gray-300 flex-grow"></span>
        </motion.h2>

        <motion.div
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8"
        >
          {skillCategories.map((category, index) => (
            <motion.div
              key={index}
              variants={itemVariants}
              className="bg-white rounded-lg shadow-md p-6 hover:shadow-lg transition-shadow duration-300"
            >
              <div className="text-accent text-3xl mb-4">
                <category.icon size={32} />
              </div>
              <h3 className="text-xl font-bold text-primary mb-4">
                {category.title}
              </h3>
              <ul className="space-y-2">
                {category.skills.map((skill, idx) => (
                  <li key={idx} className="flex items-center justify-between">
                    <span className="text-black">{skill.name}</span>
                    <div className="w-1/3 bg-gray-200 rounded-full h-2">
                      <div
                        className="bg-accent rounded-full h-2"
                        style={{ width: `${skill.proficiency}%` }}
                      ></div>
                    </div>
                  </li>
                ))}
              </ul>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  );
}
