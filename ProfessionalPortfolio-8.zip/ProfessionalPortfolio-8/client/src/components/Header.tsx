import { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { Menu, X } from "lucide-react";
import { Button } from "@/components/ui/button";

interface HeaderProps {
  activeSection: string;
}

export default function Header({ activeSection }: HeaderProps) {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 10);
    };

    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      window.scrollTo({
        top: element.offsetTop - 80,
        behavior: "smooth",
      });
    }
    setIsMobileMenuOpen(false);
  };

  const toggleMobileMenu = () => {
    setIsMobileMenuOpen(!isMobileMenuOpen);
  };

  const navLinks = [
    { name: "About", section: "about" },
    { name: "Experience", section: "experience" },
    { name: "Skills", section: "skills" },
    { name: "Education", section: "education" },
    { name: "Contact", section: "contact" },
  ];

  const headerClasses = `fixed w-full z-50 transition-all duration-300 ${
    isScrolled ? "bg-white shadow-sm bg-opacity-90 py-2" : "bg-transparent py-4"
  }`;

  return (
    <header className={headerClasses}>
      <div className="container mx-auto px-6">
        <nav className="flex justify-between items-center">
          <motion.a
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.5 }}
            href="#hero"
            className="text-2xl font-bold text-primary cursor-pointer"
            onClick={() => scrollToSection("hero")}
          >
            SN
          </motion.a>

          {/* Mobile Menu Button */}
          <div className="lg:hidden">
            <Button
              variant="ghost"
              size="icon"
              onClick={toggleMobileMenu}
              aria-label="Toggle menu"
            >
              {isMobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
            </Button>
          </div>

          {/* Desktop Navigation */}
          <ul className="hidden lg:flex space-x-8">
            {navLinks.map(({ name, section }, index) => (
              <motion.li
                key={section}
                initial={{ opacity: 0, y: -20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.3, delay: index * 0.1 + 0.1 }}
              >
                <a
                  href={`#${section}`}
                  onClick={() => scrollToSection(section)}
                  className={`relative font-medium hover:text-accent pb-1 ${
                    activeSection === section
                      ? "text-accent"
                      : "text-primary"
                  }`}
                >
                  {name}
                  {activeSection === section && (
                    <motion.span
                      layoutId="activeSection"
                      className="absolute bottom-0 left-0 w-full h-0.5 bg-accent"
                      transition={{ type: "spring", stiffness: 380, damping: 30 }}
                    />
                  )}
                </a>
              </motion.li>
            ))}
          </ul>

          
        </nav>
      </div>

      {/* Mobile Menu */}
      {isMobileMenuOpen && (
        <motion.div
          initial={{ opacity: 0, height: 0 }}
          animate={{ opacity: 1, height: "auto" }}
          exit={{ opacity: 0, height: 0 }}
          transition={{ duration: 0.3 }}
          className="lg:hidden bg-white border-t border-gray-100"
        >
          <div className="container mx-auto px-6 py-4">
            <ul className="space-y-4">
              {navLinks.map(({ name, section }) => (
                <li key={section}>
                  <a
                    href={`#${section}`}
                    onClick={() => scrollToSection(section)}
                    className={`block font-medium ${
                      activeSection === section
                        ? "text-accent"
                        : "text-primary hover:text-accent"
                    }`}
                  >
                    {name}
                  </a>
                </li>
              ))}
            </ul>
          </div>
        </motion.div>
      )}
    </header>
  );
}
